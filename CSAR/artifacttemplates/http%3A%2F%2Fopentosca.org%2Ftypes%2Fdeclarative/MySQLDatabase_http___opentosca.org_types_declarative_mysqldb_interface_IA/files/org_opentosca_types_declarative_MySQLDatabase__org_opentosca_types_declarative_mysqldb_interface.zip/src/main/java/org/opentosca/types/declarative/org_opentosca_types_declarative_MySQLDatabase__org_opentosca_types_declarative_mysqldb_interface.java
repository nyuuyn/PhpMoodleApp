package org.opentosca.types.declarative;

import java.util.HashMap;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService
public class org_opentosca_types_declarative_MySQLDatabase__org_opentosca_types_declarative_mysqldb_interface extends AbstractIAService {

	@WebMethod
	@SOAPBinding
	@Oneway
	public void executeSQLFile(
		@WebParam(name="dbname", targetNamespace="http://declarative.types.opentosca.org/") String dbname,
		@WebParam(name="dbpassword", targetNamespace="http://declarative.types.opentosca.org/") String dbpassword,
		@WebParam(name="dbip", targetNamespace="http://declarative.types.opentosca.org/") String dbip,
		@WebParam(name="sqlStatement", targetNamespace="http://declarative.types.opentosca.org/") String sqlStatement
	) {
		// TODO: Implement your operation here.
	}

	@WebMethod
	@SOAPBinding
	@Oneway
	public void executeSQL(
		@WebParam(name="dbname", targetNamespace="http://declarative.types.opentosca.org/") String dbname,
		@WebParam(name="dbpassword", targetNamespace="http://declarative.types.opentosca.org/") String dbpassword,
		@WebParam(name="dbip", targetNamespace="http://declarative.types.opentosca.org/") String dbip,
		@WebParam(name="fileRef", targetNamespace="http://declarative.types.opentosca.org/") String fileRef
	) {
		// TODO: Implement your operation here.
	}



}
