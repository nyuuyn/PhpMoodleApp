- S3.php -

Amazon S3 PHP Class

Cloned from git://github.com/tpyo/amazon-s3-php-class.git
At commit 8413f6f70ad3bb79ae756958d4ba2238514b00af

https://github.com/tpyo/amazon-s3-php-class
http://undesigned.org.za/2007/10/22/amazon-s3-php-class
